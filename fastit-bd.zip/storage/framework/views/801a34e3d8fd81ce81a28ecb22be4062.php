<?php $__env->startSection('section-title', 'User'); ?>
<?php $__env->startSection('page-title', 'Update'); ?>
<?php $__env->startSection('action-button'); ?>
    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary-rgba">
        <i class="mr-2 feather icon-list"></i>
        User List
    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-30">
                <div class="card-header">
                    <h4 class="card-title font-weight-bold">Add User</h4>
                </div>
                <div class="card-body">
                    <form class="needs-validation" novalidate action="<?php echo e(route('users.update', $user->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            
                            <div class="mb-3 col-md-12">
                                <label for="validationCustom01" class="form-label font-weight-bold">
                                    Name
                                </label>
                                <input type="text" class="form-control" id="validationCustom01"
                                    placeholder="Enter User Name" name="name" required value="<?php echo e($user->name); ?>">
                            </div>
                            
                            <div class="mb-3 col-md-6">
                                <label for="validationCustom02" class="form-label font-weight-bold">
                                    Email</label>
                                <input type="email" class="form-control" id="validationCustom02"
                                    placeholder="Enter User Email" name="email" required value="<?php echo e($user->email); ?>">
                            </div>
                            
                            <div class="mb-3 col-md-6">
                                <label for="validationCustom03" class="form-label font-weight-bold">
                                    Phone</label>
                                <input type="text" class="form-control" id="validationCustom03"
                                    placeholder="Enter User Phone" name="phone" required value="<?php echo e($user->phone); ?>">
                            </div>
                            
                            <div class="mb-3 col-md-6">
                                <label for="validationCustom06" class="form-label font-weight-bold">
                                    User Role</label>
                                <select class="form-control single-select" id="validationCustom06" name="role_id" required>
                                    <option value="">Select Role</option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->id); ?>"
                                            <?php echo e($user->role_id == $role->id ? 'selected' : ''); ?>><?php echo e($role->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            <div class="mb-3 col-md-6">
                                <label for="validationCustom07" class="form-label font-weight-bold">
                                    User Status</label>
                                <select class="form-control single-select" id="validationCustom07" name="status" required>
                                    <option value="">Select Status</option>
                                    <option value="1" <?php echo e($user->status == 1 ? 'selected' : ''); ?>>Active</option>
                                    <option value="0" <?php echo e($user->status == 0 ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>
                            
                            <div class="mb-3 col-md-12">
                                <label for="validationCustom08" class="form-label font-weight-bold">
                                    Address</label>
                                <textarea class="form-control" id="validationCustom08" rows="5" placeholder="Enter User Address" name="address"
                                    required><?php echo e($user->address); ?></textarea>
                            </div>
                            
                            <div class="mb-3 col-md-12">
                                <label for="validationCustom10" class="form-label font-weight-bold">
                                    Image</label>
                                <div class="col-md-8 d-flex">
                                    <input class="mr-5 form-control" id="validationCustom10" type="file" name="image"
                                        onchange="document.getElementById('showImage').src = window.URL.createObjectURL(this.files[0])"
                                        required>
                                    <img id="showImage" style="max-width: 100px; max-height: 100px;"
                                        src="<?php echo e(asset('backend/images/users/' . $user->image)); ?>" alt="your image" />
                                </div>
                            </div>
                        </div>
                        <div class="mt-4 form-group d-flex justify-content-center">
                            <button class="mr-2 btn btn-primary" type="submit">Submit</button>
                            <button class="btn btn-danger">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limon/Documents/My Files/MyPOS/random-it-single-pos/resources/views/backend/pages/user/edit.blade.php ENDPATH**/ ?>