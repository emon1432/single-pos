<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Orbiter is a bootstrap minimal & clean admin template">
    <meta name="keywords"
        content="admin, admin panel, admin template, admin dashboard, responsive, bootstrap 4, ui kits, ecommerce, web app, crm, cms, html, sass support, scss">
    <meta name="author" content="Themesbox">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>Single POS - <?php echo $__env->yieldContent('page-title'); ?></title>
    <!-- Fevicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('backend')); ?>/images/favicon.ico">
    <!-- Start css -->
    
    <!-- Switchery css -->
    <link href="<?php echo e(asset('backend')); ?>/plugins/switchery/switchery.min.css" rel="stylesheet">
    <!-- Apex css -->
    <link href="<?php echo e(asset('backend')); ?>/plugins/apexcharts/apexcharts.css" rel="stylesheet">
    <!-- Slick css -->
    <link href="<?php echo e(asset('backend')); ?>/plugins/slick/slick.css" rel="stylesheet">
    <link href="<?php echo e(asset('backend')); ?>/plugins/slick/slick-theme.css" rel="stylesheet">
    <link href="<?php echo e(asset('backend')); ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('backend')); ?>/css/icons.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('backend')); ?>/css/flag-icon.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('backend')); ?>/css/style.css" rel="stylesheet" type="text/css">
    <!-- Summernote css -->
    <link href="<?php echo e(asset('backend')); ?>/plugins/summernote/summernote-bs4.css" rel="stylesheet">
    <!-- iziToast css -->
    <link href="<?php echo e(asset('backend')); ?>/plugins/iziToast/css/iziToast.css" rel="stylesheet">
    <!-- toggle css -->
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <!-- End css -->
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body class="vertical-layout">
    <div id="containerbar">
        <?php echo $__env->make('backend.layouts.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="rightbar">
            <?php echo $__env->make('backend.layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('backend.layouts.includes.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="contentbar">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <?php echo $__env->make('backend.layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <!-- Start js -->
    <script src="<?php echo e(asset('backend')); ?>/js/jquery.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/popper.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/modernizr.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/detect.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/jquery.slimscroll.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/vertical-menu.js"></script>
    <!-- Switchery js -->
    <script src="<?php echo e(asset('backend')); ?>/plugins/switchery/switchery.min.js"></script>
    <!-- Apex js -->
    <script src="<?php echo e(asset('backend')); ?>/plugins/apexcharts/apexcharts.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/plugins/apexcharts/irregular-data-series.js"></script>
    <!-- Slick js -->
    <script src="<?php echo e(asset('backend')); ?>/plugins/slick/slick.min.js"></script>
    <!-- Custom Dashboard js -->
    <script src="<?php echo e(asset('backend')); ?>/js/custom/custom-dashboard.js"></script>
    <!-- Summernote js -->
    <script src="<?php echo e(asset('backend')); ?>/plugins/summernote/summernote-bs4.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/custom/custom-form-editor.js"></script>
    <!-- Core js -->
    <script src="<?php echo e(asset('backend')); ?>/js/core.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/status-update.js"></script>
    <!-- toggle js -->
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <!-- iziToast js -->
    <script src="<?php echo e(asset('backend')); ?>/plugins/iziToast/js/iziToast.js"></script>
    <?php echo $__env->make('vendor.lara-izitoast.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End js -->
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH /home/limon/Documents/My Files/MyPOS/random-it-single-pos/resources/views/backend/layouts/master.blade.php ENDPATH**/ ?>