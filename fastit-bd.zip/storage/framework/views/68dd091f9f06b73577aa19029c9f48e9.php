<div class="leftbar">
    <div class="sidebar">
        <div class="logobar">
            
                    <h3 class="text-white logo logo-large">RandomIT</h3>
            
                    <h5 class="logo logo-small">rIT</h5>
        </div>
        <div class="navigationbar">
            <ul class="vertical-menu">
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/dashboard.svg" class="img-fluid"
                            alt="dashboard">
                        <span>Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('users.index')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>POS</span>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('users.index')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Sale List</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('users.index')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Return List</span>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('users.index')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Damage</span>
                    </a>
                </li>

                <li>
                    <a href="javaScript:void();">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Purchase</span>
                        <i class="feather icon-chevron-right pull-right"></i>
                    </a>
                    <ul class="vertical-submenu">
                        <?php if(check_permission('users.create')): ?>
                            <li>
                                <a href="<?php echo e(route('users.create')); ?>">
                                    Create Purchase
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(check_permission('users.index')): ?>
                            <li>
                                <a href="<?php echo e(route('users.index')); ?>">
                                    Purchase List
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
                

                <?php if(check_permission('units.index')): ?>
                <li>
                    <a href="<?php echo e(route('units.index')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        Unit
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if(check_permission('users.index')): ?>
                    <li>
                        <a href="<?php echo e(route('users.index')); ?>">
                            <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                            Brand
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(check_permission('users.index')): ?>
                    <li>
                        <a href="<?php echo e(route('users.create')); ?>">
                            <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                            Category
                        </a>
                    </li>
                <?php endif; ?>

                
                <li>
                    <a href="javaScript:void();">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Products</span>
                        <i class="feather icon-chevron-right pull-right"></i>
                    </a>
                    <ul class="vertical-submenu">
                        
                    </ul>
                </li>

                <li>
                    <a href="<?php echo e(route('customers.index')); ?>" class="<?php echo e(request()->is('customers*') ? 'active' : ''); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Customers</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('suppliers.index')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Suppliers</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('customers.index')); ?>" class="<?php echo e(request()->is('customers*') ? 'active' : ''); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Expense</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('customers.index')); ?>" class="<?php echo e(request()->is('customers*') ? 'active' : ''); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Payment</span>
                    </a>
                </li>


                <li>
                    <a href="<?php echo e(route('suppliers.index')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Promotional SMS</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('suppliers.index')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Accounts</span>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('suppliers.index')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Reports</span>
                    </a>
                </li>
                
                
                <?php if(main_menu_permission('users')): ?>
                    <li>
                        <a href="javaScript:void();">
                            <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                                alt="basic">
                            <span>User Management</span>
                            <i class="feather icon-chevron-right pull-right"></i>
                        </a>
                        <ul class="vertical-submenu">
                            <?php if(check_permission('users.create')): ?>
                                <li>
                                    <a href="<?php echo e(route('users.create')); ?>">
                                        Add User
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(check_permission('users.index')): ?>
                                <li>
                                    <a href="<?php echo e(route('users.index')); ?>">
                                        User List
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(main_menu_permission('roles-permission')): ?>
                    <li>
                        <a href="javaScript:void();">
                            <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                                alt="basic">
                            <span>Role Management</span>
                            <i class="feather icon-chevron-right pull-right"></i>
                        </a>
                        <ul class="vertical-submenu">
                            <?php if(check_permission('roles-permission.index')): ?>
                                <li>
                                    <a href="<?php echo e(route('roles-permission.index')); ?>">
                                        Role & Permission
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <li>
                    <a href="<?php echo e(route('suppliers.index')); ?>">
                        <img src="<?php echo e(asset('backend')); ?>/images/svg-icon/basic.svg" class="img-fluid"
                            alt="basic">
                        <span>Backup</span>
                    </a>
                </li>
                
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /home/limon/Documents/My Files/MyPOS/random-it-single-pos/resources/views/backend/layouts/includes/sidebar.blade.php ENDPATH**/ ?>