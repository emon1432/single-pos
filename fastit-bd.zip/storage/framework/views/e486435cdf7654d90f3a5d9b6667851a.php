<div class="footerbar">
    <footer class="footer">
        <p class="mb-0">© 2023 RandomIT - All Rights Reserved.</p>
    </footer>
</div>
<?php /**PATH /home/limon/Documents/My Files/MyPOS/random-it-single-pos/resources/views/backend/layouts/includes/footer.blade.php ENDPATH**/ ?>