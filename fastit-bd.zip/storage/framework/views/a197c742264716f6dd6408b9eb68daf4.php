<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title' => '',
    'sizeClass' => '',
    'submitBtnClass' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title' => '',
    'sizeClass' => '',
    'submitBtnClass' => '',
]); ?>
<?php foreach (array_filter(([
    'title' => '',
    'sizeClass' => '',
    'submitBtnClass' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
    <div class="modal" id="addModal" tabindex="-1" role="dialog" aria-labelledby="Delete"
        aria-hidden="true">
        <div class="modal-dialog <?php echo e($sizeClass); ?>" role="document">
            <div class="px-4 modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e($title); ?></h5>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <div class="row">
                            <?php echo e($slot); ?>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success <?php echo e($submitBtnClass); ?> save">Save</button>
                </div>
            </div>
        </div>
    </div><?php /**PATH /home/limon/Documents/My Files/MyPOS/random-it-single-pos/resources/views/components/add-modal.blade.php ENDPATH**/ ?>