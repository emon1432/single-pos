<?php $__env->startSection('section-title', 'User'); ?>
<?php $__env->startSection('page-title', 'List'); ?>
<?php if(check_permission('users.create')): ?>
    <?php $__env->startSection('action-button'); ?>
        <a class="btn btn-primary-rgba" href="<?php echo e(route('users.create')); ?>">
            <i class="mr-2 feather icon-plus"></i>
            Add User
        </a>
    <?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-30">
                <div class="card-header">
                    <h5 class="card-title">User List</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="datatable-buttons" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Photo</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>User Role</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('backend')); ?>/images/users/<?php echo e($user->image); ?>"
                                                alt="<?php echo e($user->name); ?>" width="50px" height="50px">
                                        </td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->phone); ?></td>
                                        <td><?php echo e($user->role->name); ?></td>
                                        <td>
                                            <input type="checkbox" data-toggle="toggle" data-on="Active"
                                                class="status-update" <?php echo e($user->status == 1 ? 'checked' : ''); ?>

                                                data-off="Inactive" data-onstyle="success" data-offstyle="danger"
                                                data-id="<?php echo e($user->id); ?>" data-model="User">
                                        </td>
                                        <td>
                                            <?php if(check_permission('users.edit')): ?>
                                                <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                                                    class="btn btn-primary-rgba">
                                                    <i class="feather icon-edit"></i>
                                                </a>
                                            <?php endif; ?>
                                            <?php if(check_permission('users.destroy')): ?>
                                                <button class="btn btn-danger-rgba">
                                                    <i class="feather icon-trash"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limon/Documents/My Files/MyPOS/random-it-single-pos/resources/views/backend/pages/user/index.blade.php ENDPATH**/ ?>