<?php $__env->startSection('section-title', 'Role & Permission'); ?>
<?php $__env->startSection('page-title', 'List'); ?>
<?php $__env->startSection('action-button'); ?>
    <a class="btn btn-primary-rgba" href="<?php echo e(route('roles-permission.create')); ?>">
        <i class="mr-2 feather icon-plus"></i>
        Add Role & Permission
    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-30">
                <div class="card-header">
                    <h5 class="card-title">Role & Permission List</h5>
                </div>
                <div class="card-body">
                    <h6 class="card-subtitle">Export data to Copy, CSV, Excel & Note.</h6>
                    <div class="table-responsive">
                        <table id="datatable-buttons" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Role Name</th>
                                    <th>Total User</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($role->name); ?></td>
                                        <td><?php echo e($role->users->count()); ?></td>
                                        <td>
                                            <input type="checkbox" data-toggle="toggle" data-on="Active"
                                                class="status-update" <?php echo e($role->status == 1 ? 'checked' : ''); ?>

                                                data-off="Inactive" data-onstyle="success" data-offstyle="danger"
                                                data-id="<?php echo e($role->id); ?>" data-model="Role">
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('roles-permission.edit', $role->id)); ?>"
                                                class="btn btn-primary-rgba">
                                                <i class="feather icon-edit"></i>
                                            </a>
                                        </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limon/Documents/My Files/MyPOS/random-it-single-pos/resources/views/backend/pages/roles-permission/index.blade.php ENDPATH**/ ?>