<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title' => '',
    'id' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title' => '',
    'id' => '',
]); ?>
<?php foreach (array_filter(([
    'title' => '',
    'id' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="modal modal-danger fade" id="deleteModal-<?php echo e($id); ?>" tabindex="-1" role="dialog" aria-labelledby="Delete"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="px-4 modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e($title); ?></h5>
            </div>
            <div class="modal-body">
                <div class="col-md-12">
                    <div class="row">
                        <h4 class="text-center">
                            Are you sure? <br>
                            You want to <span class="text-danger">DELETE</span> This <?php echo e($title); ?>?
                        </h4>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-danger delete">Delete</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/limon/Documents/My Files/MyPOS/random-it-single-pos/resources/views/components/delete-modal.blade.php ENDPATH**/ ?>