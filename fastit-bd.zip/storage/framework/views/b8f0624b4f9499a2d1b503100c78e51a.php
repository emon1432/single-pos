<div class="breadcrumbbar">
    <div class="row align-items-center">
        <div class="col-md-8 col-lg-8">
            <h4 class="page-title"><?php echo $__env->yieldContent('page-title'); ?></h4>
            <div class="breadcrumb-list">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <?php
                        $section_title = explode('-', $__env->yieldContent('section-title'));
                    ?>
                    <?php if($section_title): ?>
                        <?php $__currentLoopData = $section_title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section_title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($section_title != ''): ?>
                                <li class="breadcrumb-item"><a href="javaScript:void();"><?php echo e($section_title); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo $__env->yieldContent('page-title'); ?></li>
                </ol>
            </div>
        </div>
        <div class="col-md-4 col-lg-4">
            <div class="widgetbar">
                <?php echo $__env->yieldContent('action-button'); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/limon/Documents/My Files/MyPOS/random-it-single-pos/resources/views/backend/layouts/includes/breadcrumb.blade.php ENDPATH**/ ?>