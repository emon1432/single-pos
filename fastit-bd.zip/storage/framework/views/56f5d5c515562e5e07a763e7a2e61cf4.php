<?php $__env->startSection('section-title', 'Role & Permission'); ?>
<?php $__env->startSection('page-title', 'Update'); ?>
<?php $__env->startSection('action-button'); ?>
    <a href="<?php echo e(route('roles-permission.index')); ?>" class="btn btn-primary-rgba">
        <i class="mr-2 feather icon-list"></i>
        Role & Permission List
    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-30">
                <div class="card-header">
                    <h4 class="card-title font-weight-bold">Update Role & Permission</h4>
                </div>
                <div class="card-body">
                    <form class="needs-validation" action="<?php echo e(route('roles-permission.update', $role->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row d-flex justify-content-center">
                            <div class="col-md-3"></div>
                            <div class="mb-3 col-md-6">
                                <label for="validationCustom01" class="form-label font-weight-bold">
                                    Role Name
                                </label>
                                <input type="text" class="form-control" id="validationCustom01"
                                    placeholder="Enter Role Name" name="name" required value="<?php echo e($role->name); ?>">
                            </div>
                            <div class="col-md-3"></div>
                        </div>
                        <div class="card" style="border: 1px solid black;">
                            <div class="card-header bg-secondary">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h4 class="card-title">Permission</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <?php $__currentLoopData = $routeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3">
                                            <div class="card" style="border: 1px solid black;">
                                                <div class="card-header bg-secondary">
                                                    <div class="custom-control custom-checkbox">
                                                        <input class="custom-control-input" type="checkbox"
                                                            id="<?php echo e($key); ?>"
                                                            onclick="$('.<?php echo e($key); ?>').prop('checked', this.checked);">
                                                        <label class="custom-control-label font-weight-bold text-dark"
                                                            for="<?php echo e($key); ?>">
                                                            <?php echo e(str_replace('-', ' ', str_replace('_', ' ', ucfirst($key)))); ?>

                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="card-body">
                                                    <?php $__currentLoopData = $routeList[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="custom-control custom-checkbox">
                                                            <input class="custom-control-input <?php echo e($key); ?>"
                                                                type="checkbox" id="<?php echo e($key); ?><?php echo e($item); ?>"
                                                                <?php echo e($value == 1 ? 'checked' : ''); ?>

                                                                name="permission[<?php echo e($key); ?>][]"
                                                                value="<?php echo e($item); ?>">
                                                            <label class="custom-control-label font-weight-bold"
                                                                for="<?php echo e($key); ?><?php echo e($item); ?>">
                                                                <?php echo e(str_replace('-', ' ', str_replace('_', ' ', ucfirst($item)))); ?>

                                                            </label>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer mt-3">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary-rgba">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/limon/Documents/My Files/MyPOS/random-it-single-pos/resources/views/backend/pages/roles-permission/edit.blade.php ENDPATH**/ ?>