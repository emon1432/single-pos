<div class="footerbar">
    <footer class="footer">
        <p class="mb-0">© 2023 RandomIT - All Rights Reserved.</p>
    </footer>
</div>
